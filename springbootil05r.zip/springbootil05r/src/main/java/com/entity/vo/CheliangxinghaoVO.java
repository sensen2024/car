package com.entity.vo;

import com.entity.CheliangxinghaoEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 车辆型号
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2021-04-26 11:54:44
 */
public class CheliangxinghaoVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 				
}
